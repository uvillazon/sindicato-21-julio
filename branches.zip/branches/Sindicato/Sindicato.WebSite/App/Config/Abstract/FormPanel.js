Ext.define("App.Config.Abstract.FormPanel", {
    extend: "Ext.form.Panel",
    frame: true,
    autoScroll: true,
    region : "center",
    //title: "Datos Generales Puestos Reconectadores",
    width: "55%",
    //    autoScroll: true,

});
