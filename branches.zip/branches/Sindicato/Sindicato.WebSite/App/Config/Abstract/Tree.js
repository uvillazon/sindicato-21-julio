/**
 * @class Bleext.abstract.Tree
 * @extends Ext.tree.Panel
 * requires 
 * @autor Crysfel Villa
 * @date Fri Aug  5 19:51:18 CDT 2011
 *
 * Description
 *
 *
 **/

Ext.define("Bleext.abstract.Tree",{
	extend		: "Ext.tree.Panel",
	
	
	initComponent	: function() {
		var me = this;
		
        
		me.callParent();
	}
});