﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sindicato.Services.Model
{
    public class AutosModel
    {
        public int? ID_SOCIO_MOVIL_AUTO { get; set; }
        public int? ID_SOCIO_MOVIL { get; set; }
        public int? ID_AUTO { get; set; }
        public string PLACA { get; set; }
        public string COLOR { get; set; }
        public string MODELO { get; set; }
        public string MARCA { get; set; }
    }
}
