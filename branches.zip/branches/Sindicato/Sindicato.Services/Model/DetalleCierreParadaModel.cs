﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sindicato.Services.Model
{
    public class DetalleCierreParadaModel
    {
        
        public decimal INGRESO  { get; set; }
        public decimal EGRESO { get; set; }
        public string DETALLE { get; set; }
        public string CIERRE { get; set; }
    }
}
