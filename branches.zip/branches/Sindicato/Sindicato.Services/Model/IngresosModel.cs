﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sindicato.Services.Model
{
    public class IngresosModel
    {
        public int? ID_INGRESO { get; set; }
        public int? ID_TIPO_INGRESO { get; set; }
        public int? ID_TIPO_TIPO { get; set; }
        public int? ID_SOCIO_MOVIL { get; set; }
        public int? ID_TIPO { get; set; }
        public int? ID_SOCIO { get; set; }
        public int? ID_PRESTAMO { get; set; }
        public int? ID_DEUDA { get; set; }
        //public int? ID_DESCUENTO { get; set; }
        //public int? ID_SOCIO { get; set; }
    }
}
