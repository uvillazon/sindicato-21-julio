﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sindicato.Services.Model
{
    public class ParametrosModel
    {
       
        public string CODIGO { get; set; }
        public string ESTADO { get; set; }
        public string TIPO { get; set; }
        public int? ID_LINEA { get; set; }
    }
}
