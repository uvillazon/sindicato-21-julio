﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sindicato.Services.Model
{
    public class ParadasModel
    {
        public int? ID_PARADA { get; set; }
        public int? ID_CIERRE { get; set; }
        
    }
}
